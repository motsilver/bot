# Coloque o bot nesta pasta
## Nota: o bot trabalha separado do resto